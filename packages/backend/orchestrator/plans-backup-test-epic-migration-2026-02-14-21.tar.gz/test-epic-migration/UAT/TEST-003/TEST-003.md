---
id: TEST-003
title: Test Story in UAT
type: feature
priority: critical
---

# Test Story in UAT

This is a test story in the UAT directory.
