---
id: TEST-005
title: Story with Subdirectories
type: feature
---

# Story with Subdirectories

This story has _pm and _implementation subdirectories.
