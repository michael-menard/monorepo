PM notes
