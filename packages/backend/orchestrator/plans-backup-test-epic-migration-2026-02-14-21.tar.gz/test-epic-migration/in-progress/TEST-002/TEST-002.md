---
id: TEST-002
title: Test Story in Progress
type: feature
priority: high
---

# Test Story in Progress

This is a test story in the in-progress directory.
